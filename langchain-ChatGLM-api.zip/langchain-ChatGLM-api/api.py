# -- coding: utf-8 --**
from fastapi import FastAPI, Request
from transformers import AutoTokenizer, AutoModel
import uvicorn, json, datetime
import torch
from configs.model_config import *
from chains.local_doc_qa import LocalDocQA
import nest_asyncio
from pyngrok import ngrok
import uvicorn
from fastapi.middleware.cors import CORSMiddleware


# return top-k text chunk from vector store
VECTOR_SEARCH_TOP_K = 10

# LLM input history length
LLM_HISTORY_LEN = 3

# Show reply with source text from input document
REPLY_WITH_SOURCE = True

DEVICE = "cuda"
DEVICE_ID = "0"
CUDA_DEVICE = f"{DEVICE}:{DEVICE_ID}" if DEVICE_ID else DEVICE
local_doc_qa = LocalDocQA()
local_doc_qa.init_cfg(llm_model=LLM_MODEL,
                embedding_model=EMBEDDING_MODEL,
                embedding_device=EMBEDDING_DEVICE,
                llm_history_len=LLM_HISTORY_LEN,
                top_k=VECTOR_SEARCH_TOP_K)
filepath = "/content/langchain-ChatGLM-api/content/faq.txt"
vs_path = local_doc_qa.init_knowledge_vector_store(filepath)

def torch_gc():
    if torch.cuda.is_available():
        with torch.cuda.device(CUDA_DEVICE):
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
history = []
@app.post("/")
async def create_item(request: Request):
    global model, tokenizer
    json_post_raw = await request.json()
    print(json_post_raw)
    json_post = json.dumps(json_post_raw)
    json_post_list = json.loads(json_post)
    prompt = json_post_list.get('prompt')
    history = json_post_list.get('history')
    # max_length = json_post_list.get('max_length')
    # top_p = json_post_list.get('top_p')
    temperature = json_post_list.get('temperature')
    # query = input("Input your question 请输入问题：")
    resp, history = local_doc_qa.get_knowledge_based_answer(query=prompt,
                                  vs_path=vs_path,
                                  chat_history=history)
    if REPLY_WITH_SOURCE:
        print(resp)
    else:
        print(resp["result"])
    now = datetime.datetime.now()
    time = now.strftime("%Y-%m-%d %H:%M:%S")
    answer = {
        "response": resp,
        "history": history,
        "status": 200,
        "time": time
    }
    log = "[" + time + "] " + '", prompt:"' + prompt + '", response:"' + repr(resp) + '"'
    print(log)
    torch_gc()
    return answer


if __name__ == '__main__':
    ngrok_tunnel = ngrok.connect(8000)
    print('Public URL:', ngrok_tunnel.public_url)
    nest_asyncio.apply()
    uvicorn.run(app, port=8000)
    # uvicorn.run(app, host='0.0.0.0', port=8000, workers=1)